﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Chama.CourseSignUp.TechnicalTest.Application.Commands
{
    public class CreateAppplicationCommandHandles
    {
    }
}
