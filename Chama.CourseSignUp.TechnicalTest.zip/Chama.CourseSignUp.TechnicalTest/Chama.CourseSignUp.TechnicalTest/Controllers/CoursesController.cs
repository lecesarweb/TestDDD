﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Chama.CourseSignUp.TechnicalTest.Controllers
{
    [ApiController]
    [Route("coursesignup")]
    public class CoursesController : ControllerBase
    {


        [HttpGet]
        [Route("course")]
        public async Task<dynamic> GetCourseAsync(int Id)
        {
            return await Task.FromResult("Teste");
        }

        [HttpPost]
        [Route("course")]
        public async Task<dynamic> CourseAsync([FromBody] dynamic obj)
        {
            return await Task.FromResult("Teste");
        }
    }
}
